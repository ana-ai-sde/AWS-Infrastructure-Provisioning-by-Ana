import boto3
import json
import os

def handler(event, context):
    sagemaker = boto3.client('sagemaker')
    endpoint_name = os.environ['ENDPOINT_NAME']
    action = event.get('action', '')

    if action == 'rollback':
        try:
            # Get previous model version
            response = sagemaker.list_model_package_groups()
            # Implement rollback logic here
            return {
                'statusCode': 200,
                'body': json.dumps('Model rollback successful')
            }
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(str(e))
            }
    elif action == 'check_status':
        try:
            # Check training status
            return {
                'statusCode': 200,
                'body': json.dumps('Training status check completed')
            }
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(str(e))
            }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid action')
        }
