const AWSXRay = require('aws-xray-sdk-core');
const AWS = AWSXRay.captureAWS(require('aws-sdk'));
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  try {
    const body = JSON.parse(event.body || '{}');
    const timestamp = new Date().toISOString();
    const id = context.awsRequestId;

    // Add request metadata for tracing
    const requestMetadata = {
      requestId: context.awsRequestId,
      functionVersion: context.functionVersion,
      functionName: context.functionName,
      memoryLimitInMB: context.memoryLimitInMB,
      remainingTime: context.getRemainingTimeInMillis(),
    };

    // Store item in DynamoDB with metadata
    const item = {
      id,
      timestamp,
      requestMetadata,
      ...body,
    };

    const startTime = Date.now();
    await dynamodb.put({
      TableName: process.env.DYNAMODB_TABLE,
      Item: item
    }).promise();
    const endTime = Date.now();

    // Log operation metrics
    console.log('Operation metrics:', {
      operation: 'putItem',
      tableName: process.env.DYNAMODB_TABLE,
      latencyMs: endTime - startTime,
      itemSize: JSON.stringify(item).length,
      requestId: context.awsRequestId
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Item stored successfully',
        id,
        timestamp,
        requestMetadata
      })
    };
  } catch (error) {
    console.error('Error:', {
      message: error.message,
      stack: error.stack,
      requestId: context.awsRequestId
    });
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Internal server error',
        error: error.message,
        requestId: context.awsRequestId
      })
    };
  }
};
