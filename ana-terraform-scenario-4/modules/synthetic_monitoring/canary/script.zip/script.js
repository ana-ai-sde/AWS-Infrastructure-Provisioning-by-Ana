const synthetics = require('Synthetics');
const log = require('SyntheticsLogger');

const pageLoadBlueprint = async function () {
    const URL = 'https://example.com';
    
    log.info('Starting URL monitoring for: ' + URL);
    const page = await synthetics.getPage();
    
    const response = await page.goto(URL, {
        waitUntil: 'domcontentloaded',
        timeout: 30000
    });
    
    if (response.status() < 200 || response.status() > 299) {
        log.error('Failed to load page with status code: ' + response.status());
        throw new Error('Failed to load page with status code: ' + response.status());
    }
    
    log.info('Successfully loaded page with status code: ' + response.status());
    return 0;
};

exports.handler = async () => {
    return await pageLoadBlueprint();
};
